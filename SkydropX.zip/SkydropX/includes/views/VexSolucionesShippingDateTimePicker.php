<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexSolucionesShippingDateTimePicker {
    
    public function enqueueScripts() {
        if(is_checkout()) {
            wp_enqueue_style("datetimepicker", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/datetimepicker/jquery.datetimepicker.min.css');
            wp_enqueue_script('datetimepicker', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/datetimepicker/jquery.datetimepicker.full.min.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
        }
    }
    
    public function render($index, $method, $package) {
        if(is_checkout()) {
            $settings = VexSolucionesSkydropxShippingMethod::getSettingsForPackage($package);
            $data = [];
            if(array_key_exists("post_data", $_POST))
                parse_str($_POST["post_data"], $data);
            include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/checkoutShippingFields.php"; 
        }
    }
    
}
