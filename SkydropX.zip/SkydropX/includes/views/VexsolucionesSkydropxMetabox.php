<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexsolucionesSkydropxMetabox {
    
    const SKYDROPX_INFO_METABOX_NONCE = "skydropx_order_metabox";

    public function addToOrderDetails($postType, $post) {
        $order = wc_get_order($post->ID);
        if($order) {
            Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($order) {
                $skydropx_delivery_track = get_post_meta($order->get_id(), "skydropx_id", true);
                if(!empty($skydropx_delivery_track) || 
                        !empty(get_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE, true)))
                            add_meta_box('skydropx_info_metabox', __('Skydropx Información', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), function() use($order) {
                                global $post;
                                include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/skydropxOrderMetabox.php";
                                wp_nonce_field( basename( __FILE__ ), self::SKYDROPX_INFO_METABOX_NONCE );
                            }, 'shop_order', 'side', 'core' );
            });
        }
    }
    
}
