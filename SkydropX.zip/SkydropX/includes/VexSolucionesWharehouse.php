<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexSolucionesWharehouse {
    
    const CONF_NAME = "skydropx_wharehouses";
    const DIR1 = "warehouseDir1", DIR2 = "warehouseDir2", ZIP = "zip", REFERENCE = "businessReference", CONTACT_NAME = "contactName";
    const CONTACT_PHONE = "contactPhone", COMPANY = "company";
    const WHAREHOUSE_INDEX = "wharehouse";
    const PROVINCE = 'wharehouse_province', DISTRICT = 'wharehouse_district';
    const EMAIL = 'wharehouse_email';
    
    public $dir1, $dir2, $reference, $contactName, $contactPhone, $email;
    public $province, $district;
    
    function __construct(array $wharehouse) {
        $this->dir1 = $wharehouse[self::DIR1];
        $this->dir2 = $wharehouse[self::DIR2];
        $this->zip = $wharehouse[self::ZIP];
        $this->company = $wharehouse[self::COMPANY];
        $this->reference = $wharehouse[self::REFERENCE];
        $this->contactName = $wharehouse[self::CONTACT_NAME];
        $this->contactPhone = $wharehouse[self::CONTACT_PHONE];
        $this->province = $wharehouse[self::PROVINCE];
        $this->district = $wharehouse[self::DISTRICT];
        $this->email = $wharehouse[self::EMAIL];
    }
    
    public static function save() {
        $args = [
            self::DIR1, self::DIR2, self::ZIP, self::REFERENCE, self::CONTACT_NAME, self::CONTACT_PHONE,
           self::PROVINCE, self::DISTRICT, self::COMPANY,
            self::EMAIL
        ];
        $wharehouses = [];
        for($i = 0; $i < count($_POST[self::DIR1]); $i++) {
            foreach($args as $arg) {
                if(empty($_POST[$arg]))
                    throw new Exception(__("Existen campos vacios en el formulario de registro del almacen", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN));
                $wharehouses[$i][$arg] = sanitize_text_field($_POST[$arg][$i]);
            }
        }
        if(is_admin())
            update_option(self::CONF_NAME, $wharehouses);
        else
            update_user_meta(wp_get_current_user()->ID, self::CONF_NAME, $wharehouses);
    }
    
    /**
    * @return VexSolucionesWharehouse
    */
    public static function getClosestWharehouse(array $wharehouses, $lat, $lgt) {
        if(!count($wharehouses))
            throw new Exception(__('No hay almacenes registrados', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN));
        $closest = array_shift($wharehouses);
        foreach($wharehouses as $wharehouse) {
            if(VexSolucionesUtils::getDistanceFromLatLonInKm($lat, $lgt, $wharehouse->lat, $wharehouse->lgt)
                    <= VexSolucionesUtils::getDistanceFromLatLonInKm($lat, $lgt, $closest->lat, $lgt->lgt)) {
                $closest = $wharehouse;
            }
        }
        return $closest;
    }
    
}
