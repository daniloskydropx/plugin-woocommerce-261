<?php

/*
 * * Woocommerce skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexSolucionesSheduleHoliday {
    
    const CONF_NAME = "skydropx_shedule_holydays";
    const REASON = "reason_holiday", DATE = "holiday_date";
    
    public $reason, $datetime;
    
    function __construct(array $holiday) {
        $this->reason = $holiday[self::REASON];
        $this->datetime = $holiday[self::DATE];
    }
    
    public function getTraslatedDateTime() {
        return str_replace(VexSolucionesUtils::getMonthsTraslated(-1), VexSolucionesUtils::getMonthsTraslated(1), strtolower($this->datetime));
    }
    
    public static function save() {
        $args = [
            self::REASON, self::DATE 
        ];
        $shedules = [];
        $vaca = array_key_exists(self::REASON, $_POST) ? $_POST[self::REASON] : [];
        for($i = 0; $i < count($vaca); $i++) {
            foreach($args as $arg) {
                switch($arg) {
                    case self::DATE: {
                        $sdate = str_replace(VexSolucionesUtils::getMonthsTraslated(1), VexSolucionesUtils::getMonthsTraslated(-1), $_POST[$arg][$i]);
                        $date = strtotime($sdate);
                        if($date !== false) {
                            $dateTime = new DateTime();
                            $dateTime->setTimestamp($date);
                            $shedules[$i][$arg] = $dateTime->format("F d");
                        } else
                            throw new Exception(__("Se ha introducido una fecha inválida", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN));
                        break;
                    } default: {
                        $shedules[$i][$arg] = sanitize_text_field($_POST[$arg][$i]);
                        break;
                    }
                }
            }
        }
        if(is_admin())
            update_option(self::CONF_NAME, $shedules);
        else
            update_user_meta(wp_get_current_user()->ID, self::CONF_NAME, $shedules);
    }
    
}
