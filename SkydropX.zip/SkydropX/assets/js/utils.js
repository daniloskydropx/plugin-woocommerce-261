/* script */

  (function($){
    window.setTimeout(
      function () {
       $('form.checkout').off('input keydown change', '.address-field input.input-text, .update_totals_on_change input.input-text');
     }, 0);
        $('#billing_postcode').change(function(){
          $(".typeshipping").prop("checked", false);
          console.log('address changed');
            jQuery('body').trigger('update_checkout');
        });
     
      })(jQuery);