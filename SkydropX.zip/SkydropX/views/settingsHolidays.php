<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined( 'ABSPATH' ) || exit; ?>
<div style="width: 100%; display:none;">
    <h1 class="section-title" style="width: 100%; text-align: left;"><?php echo __( 'Días Feriados.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></h1>
    <hr>
    <div class="supervaca">
        <div id="czContainer">
            <div id="first">
                <?php include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/czRecorset.php"; ?>
            </div>
            <?php
            foreach($this->getHolidaysShedules() as $holiday):
                include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/czRecorset.php";
            endforeach; ?>
        </div>
    </div>
</div>
<br><br>