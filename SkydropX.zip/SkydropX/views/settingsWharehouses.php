<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined( 'ABSPATH' ) || exit; ?>
<hr>
<h1 class="wc-settings-sub-title"><?php echo __( 'Almacenes de recojo.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></h1>
<p><?php echo __("Almacenes donde skydropx recogerá los envíos, cuando un cliente realiza una compra, se seleccionara el almacen mas cercano a su ubicación.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></p>
<div id="" data-num-tabs="<?php echo count($this->getWharehouses()); ?>">
   <!-- <ul class="tabs-links">
        <?php
        for($i = 0; $i < count($this->getWharehouses()); $i++)
           // include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/warehouseTabLink.php"; ?>
    </ul>-->
    <?php
    $i = 0;
    foreach($this->getWharehouses() as $wharehouse):
       
        $i++;
    endforeach;
    include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/warehouseTab.php";
    unset($wharehouse); ?>
</div>
<!--<button type="button" id="add_tab" style="float: right;">
    <svg width="25" height="25" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1344 960v-128q0-26-19-45t-45-19h-256v-256q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v256h-256q-26 0-45 19t-19 45v128q0 26 19 45t45 19h256v256q0 26 19 45t45 19h128q26 0 45-19t19-45v-256h256q26 0 45-19t19-45zm320-64q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/></svg>
    <span><?php echo __("Añadir", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></span>
</button>-->

