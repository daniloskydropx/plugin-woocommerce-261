<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */ 
if($_POST['action'] == 'import'):
    if(current_user_can('administrator')) {
        update_option('skydropx_wharehouses', get_option('olva_wharehouses'));
        update_option('skydropx_shedule_holydays', get_option('olva_shedule_holydays'));
        update_option('skydropx_shedule_days', get_option('olva_shedule_days'));
    } else {
        update_user_meta(wp_get_current_user()->ID, 'skydropx_wharehouses', get_user_meta(wp_get_current_user()->ID, 'olva_wharehouses', true));
        update_user_meta(wp_get_current_user()->ID, 'skydropx_shedule_holydays', get_user_meta(get_current_user()->ID, 'olva_shedule_holydays', true));
        update_user_meta(wp_get_current_user()->ID, 'skydropx_shedule_days', get_user_meta(get_current_user()->ID, 'olva_shedule_days', true));
    }
    Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->renderNotice(__("Correcto: ", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), 'Los ajustes han sido importados.', "notice");
endif; ?>
<hr>
<h1 class="wc-settings-sub-title" style="width: 100%; text-align: left;"><?php echo __( 'Importar Ajustes Olva.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></h1>
<p><?php echo "Importa los almacenes y dias feriados del plugin olva."; ?></p>
<form method="post">
    <input type="hidden" name="action" value="import">
    <button type="submit"><?php echo __('Importar Ahora', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></button>
</form>

