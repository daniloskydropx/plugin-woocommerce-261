<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */ ?>
 <style>
    .oculta{display:none;}
    .show{display:block;}
 </style>
<table class="form-table">
    <tbody>
       <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::PROVINCE; ?>"><?php echo __( 'Estado', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
             
              <?php echo isset($wharehouse) ? '<input value="'.$wharehouse->province.'" readonly type="text"> <span class="editar"><span class="dashicons dashicons-edit"></span></span>' : ""; ?><br>
                <?php  isset($wharehouse) ? $clase="oculta" : $clase="show";?>
                <select class="<?php echo $clase;?>" name="<?php echo VexSolucionesWharehouse::PROVINCE; ?>[]" id="<?php echo VexSolucionesWharehouse::PROVINCE; ?>" required>
                    <option>Seleccione un estado</option>
                <option value='AG'>Aguascalientes</option>
<option value='BC'>Baja California</option>
<option value='BS'>Baja California Sur</option>
<option value='CM'>Campeche</option>
<option value='CS'>Chiapas</option>
<option value='CH'>Chihuahua</option>
<option value='CO'>Coahuila</option>
<option value='CL'>Colima</option>
<option value='DF'>Ciudad de México</option>
<option value='DG'>Durango</option>
<option value='GT'>Guanajuato</option>
<option value='GR'>Guerrero</option>
<option value='HG'>Hidalgo</option>
<option value='JA'>Jalisco</option>
<option value='MX'>Estado de Mexico</option>
<option value='MI'>Michoacán</option>
<option value='MO'>Morelos</option>
<option value='NA'>Nayarit</option>
<option value='NL'>Nuevo León</option>
<option value='OA'>Oaxaca</option>
<option value='PU'>Puebla</option>
<option value='QT'>Querétaro</option>
<option value='QR'>Quintana Roo</option>
<option value='SL'>San Luis Potosí</option>
<option value='SI'>Sinaloa</option>
<option value='SO'>Sonora</option>
<option value='TB'>Tabasco</option>
<option value='TM'>Tamaulipas</option>
<option value='TL'>Tlaxcala</option>
<option value='VE'>Veracruz</option>
<option value='YU'>Yucatán</option>
<option value='ZA'>Zacatecas</option>
                </select>
            </td>
        </tr>
           <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DISTRICT; ?>"><?php echo __( 'Ciudad', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DISTRICT; ?>[]" id="<?php echo VexSolucionesWharehouse::DISTRICT; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->district : ""; ?>" required>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DIR1; ?>"><?php echo __( 'Dirección 1', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DIR1; ?>[]" id="<?php echo VexSolucionesWharehouse::DIR1; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->dir1 : ""; ?>" required>
            </td>
        </tr>
        <tr>
        <tr>
 <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DIR2; ?>"><?php echo __( 'Dirección 2', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DIR2; ?>[]" id="<?php echo VexSolucionesWharehouse::DIR2; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->dir2 : ""; ?>" required>
            </td>
        </tr>

            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::ZIP; ?>"><?php echo __( 'Código Zip', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="number" name="<?php echo VexSolucionesWharehouse::ZIP; ?>[]" id="<?php echo VexSolucionesWharehouse::ZIP; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->zip : ""; ?>" required>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::REFERENCE; ?>"><?php echo __( 'Referencia del comercio', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::REFERENCE; ?>[]" id="<?php echo VexSolucionesWharehouse::REFERENCE; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->reference : ""; ?>" required>
            </td>
        </tr>
        <tr>
                    <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::COMPANY; ?>"><?php echo __( 'Nombre de la empresa', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" id="company" name="<?php echo VexSolucionesWharehouse::COMPANY; ?>[]" id="<?php echo VexSolucionesWharehouse::COMPANY; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->company : ""; ?>" required>
                <input type="hidden" id="compania" name="compania">
            </td>
        </tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>"><?php echo __( 'Nombre del contacto', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>[]" id="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->contactName : ""; ?>" required>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::EMAIL; ?>"><?php echo __( 'Email', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="email" name="<?php echo VexSolucionesWharehouse::EMAIL; ?>[]" id="<?php echo VexSolucionesWharehouse::EMAIL; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->email : ""; ?>" required>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>"><?php echo __( 'Teléfono del contacto', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>[]" id="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->contactPhone : ""; ?>" required>
            </td>
        </tr>

    
    </tbody>
</table>