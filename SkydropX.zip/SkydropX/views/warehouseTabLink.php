<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */ ?>

<li id="<?php echo "link-tabs-{$i}"; ?>">
    <a href="#<?php echo "tabs-{$i}" ; ?>">
        <strong><?php echo __("Almacen", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?><span class="warehouse-number"><?php echo "&nbsp;" . ($i+1); ?></span></strong>
        <button type="button" style="padding-left: 0px; padding-right: 0px;" data-tab-index="<?php echo $i; ?>">
            <svg width="10" height="10" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1490 1322q0 40-28 68l-136 136q-28 28-68 28t-68-28l-294-294-294 294q-28 28-68 28t-68-28l-136-136q-28-28-28-68t28-68l294-294-294-294q-28-28-28-68t28-68l136-136q28-28 68-28t68 28l294 294 294-294q28-28 68-28t68 28l136 136q28 28 28 68t-28 68l-294 294 294 294q28 28 28 68z"/></svg>
        </button>
    </a>
</li>
