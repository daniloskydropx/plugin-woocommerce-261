<?php
require('../../../../wp-load.php');
global $wpdb;
$sandbox=get_option('skydropx_sandbox_mode');
$url = $sandbox === 'enabled' ? 'https://api-demo.skydropx.com' : 'https://api.skydropx.com';
$curl = curl_init();
$idshipping=$_POST['id'];
$ordeni=$_POST['ordenid'];
$token=$_POST['token'];
$paqueteria = get_post_meta($ordeni, "skydropx_paqueteria", true);
//require_once( 'http://localhost/vex/wp-load.php' );
curl_setopt_array($curl, array(
  CURLOPT_URL => "{$url}/v1/shipments/{$idshipping}",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "authorization: Token token={$token}",
    "cache-control: no-cache",
    "content-type: application/json",
    "postman-token: 33489fa3-8ee7-e658-a5f1-81e69b6278fb"
  ),
));

$response = curl_exec($curl);
$array = json_decode($response, true);

$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
}
 else {
  $data = $array['data'];
  $proveedor=$data['attributes']['provider'];
        $tipo= $data['type'];
      $status= $data['attributes']['status'];
      $update=$data['attributes']['updated_at'];
update_post_meta($ordeni, "skydropx_status", $status);
  echo'
<script type="text/javascript">
    (function($){
    $("#modal'.$ordeni.'").modal("show")
      })(jQuery);
</script>
<table style="width:100%;">
  <thead>
    <tr>
    <th>
      Tipo:
    </th>
    <th>
    Paquetería:
  </th>
    <th>
      Status:
    </th>
    <th>Fecha de actualización:</th>
    </tr>
  </thead>
  <tbody>
  <tr class="table-success">
    <td>'.$tipo.'</td>
    <td>'.$paqueteria.'</td>
        <td>'.$status.'</td>
            <td>'.$update.'</td>
  </tbody>
</table>';
}
